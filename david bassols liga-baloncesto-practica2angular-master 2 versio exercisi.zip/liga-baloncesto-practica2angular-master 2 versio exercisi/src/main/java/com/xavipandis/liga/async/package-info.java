/**
 * Async helpers.
 */
package com.xavipandis.liga.async;
