/**
 * Swagger api specific code.
 */
package com.xavipandis.liga.config.apidoc;