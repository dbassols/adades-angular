/**
 * Audit specific code.
 */
package com.xavipandis.liga.config.audit;
