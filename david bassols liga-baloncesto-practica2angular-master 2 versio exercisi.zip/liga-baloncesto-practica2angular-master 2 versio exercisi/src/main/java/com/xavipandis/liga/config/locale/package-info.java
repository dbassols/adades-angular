/**
 * Locale specific code.
 */
package com.xavipandis.liga.config.locale;
