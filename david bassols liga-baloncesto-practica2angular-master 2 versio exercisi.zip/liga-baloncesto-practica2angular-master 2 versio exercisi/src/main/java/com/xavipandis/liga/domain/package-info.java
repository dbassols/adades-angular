/**
 * JPA domain objects.
 */
package com.xavipandis.liga.domain;
