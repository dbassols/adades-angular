/**
 * Spring Data JPA repositories.
 */
package com.xavipandis.liga.repository;
