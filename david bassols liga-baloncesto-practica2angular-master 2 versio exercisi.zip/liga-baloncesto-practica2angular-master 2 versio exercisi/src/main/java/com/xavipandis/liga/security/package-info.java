/**
 * Spring Security configuration.
 */
package com.xavipandis.liga.security;
