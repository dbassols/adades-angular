/**
 * Service layer beans.
 */
package com.xavipandis.liga.service;
