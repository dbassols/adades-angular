/**
 * Spring MVC REST controllers.
 */
package com.xavipandis.liga.web.rest;
