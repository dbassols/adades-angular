/* globals $ */
'use strict';

angular.module('ligaBaloncestoApp')
    .directive('ligaBaloncestoAppPager', function() {
        return {
            templateUrl: 'scripts/components/form/pager.html'
        };
    });
