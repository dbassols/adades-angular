/* globals $ */
'use strict';

angular.module('ligaBaloncestoApp')
    .directive('ligaBaloncestoAppPagination', function() {
        return {
            templateUrl: 'scripts/components/form/pagination.html'
        };
    });
